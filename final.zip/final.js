document.getElementById("resetButton").addEventListener('click', function(){
  location.reload()
})




const words = [
  "ability", "academy", "account", "actor", "advice", "airport", "ancient", "answer", "animal", "appear",
  "balance", "beauty", "bottle", "brother", "camera", "capital", "circle", "classroom", "college", "cookie",
  "danger", "doctor", "dream", "design", "dollar", "device", "doctor", "dress", "enemy", "energy",
  "family", "friend", "future", "famous", "flower", "forest", "garden", "guitar", "history", "hobby",
  "image", "island", "jacket", "jungle", "journey", "joke", "kitchen", "kingdom", "laptop", "language",
  "library", "leader", "lunch", "money", "mother", "market", "movie", "nature", "night", "ocean",
  "orange", "online", "office", "outdoor", "party", "picture", "phone", "project", "pencil", "people",
  "quality", "queen", "quiet", "reader", "reality", "reason", "rocket", "river", "school", "season",
  "story", "space", "song", "sunlight", "student", "sugar", "street", "star", "table", "team",
  "universe", "umbrella", "under", "video", "value", "village", "vacation", "voice", "water", "world",
  "yellow", "yoga", "youth", "zebra", "zone", "zero", "zoom", "zodiac", "monkey", "zinc",
  "and", "the", "it", "is", "too", "you", "for", "not", "of", "on", "to", "in", "with", "as", "be", "by", "this",
  "that", "from", "will", "can", "are", "have", "but", "all", "up", "down", "more", "less", "your", "how", "when", 
  "where", "why", "which", "if", "there", "here", "we", "they", "me", "him", "her", "us", "them", "each", "every"
];





function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));  // Get random index
    [arr[i], arr[j]] = [arr[j], arr[i]];  // Swap elements
  }
}


    
shuffleArray(words);

// Function to display words in the textarea
function displayWordsInTextarea() {
  const textarea = document.getElementById("typeover");
  let result = '';
  
  // Shuffle and concatenate the array three times
  for (let i = 0; i < 3; i++) {
    shuffleArray(words);  // Shuffle the array each time
    result += words.join(" ") + " ";  // Join words with a space and add to the result
  }

  // Set the value of the textarea to the result
  textarea.value = result.trim();  // Remove any extra space at the end
  
  // Ensure the textarea scrolls back to the top
  textarea.scrollTop = 0;

  // Focus the textarea and set the cursor to the beginning
  textarea.focus();
  textarea.setSelectionRange(0, 0);  // Set the cursor at the start (index 0)
}

// Call the function to display the shuffled words in the textarea
displayWordsInTextarea();



let correct = 0
let incorrect = 0
let input = document.getElementById('typeover');





const originalText = input.value.split(''); // Store original text as an array of characters

  // Set focus and move cursor to the beginning when the page loads
  window.onload = function() {
    input.focus();
    input.setSelectionRange(0, 0); // Place cursor at the beginning
  };

  input.addEventListener('keydown', (e) => {
    const { selectionStart, value } = input;
    


    if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) {

    if (e.key === originalText[selectionStart]) {
      console.log('Correct key pressed');
      correct++
      originalText[selectionStart].style
      
    } else {
      console.log('Incorrect key pressed');
      incorrect++
    }


      
      // Replace the character under the cursor with the typed key
      input.value =
        value.substring(0, selectionStart) +
        e.key +
        value.substring(selectionStart + 1);
      input.setSelectionRange(selectionStart + 1, selectionStart + 1); // Move cursor forward
      e.preventDefault();
    } else if (e.key === 'Backspace') {
      // Restore the original character when Backspace is pressed
      if (selectionStart > 0) {
        input.value =
          value.substring(0, selectionStart - 1) +
          originalText[selectionStart - 1] +
          value.substring(selectionStart);
        input.setSelectionRange(selectionStart - 1, selectionStart - 1); // Move cursor backward
        e.preventDefault();
      }

    

    let typedText = input.value.split('');


    
   
  }});





  

let isTimerActive = false; // Flag to track if the timer is active
const accOutput = document.getElementById("accuracy");

document.getElementById("timeButton").addEventListener('click', function () {
    const timerAmt = document.getElementById('mode').value;
    const stats = document.querySelector('.stats');
  
  // Show stats section when the timer starts
  stats.style.display = 'block';
    // Check if the timer is already active
    if (isTimerActive) {
        alert("Timer is already running!");
        return; // Exit the function
    }

    // Set the timer as active
    isTimerActive = true;

    function startCountdown(durationInSeconds) {
        input.focus();
        input.setSelectionRange(0, 0);
        let remainingTime = durationInSeconds;

        const timerInterval = setInterval(() => {
            const minutes = Math.floor(remainingTime / 60);
            const seconds = remainingTime % 60;

            let timeOutput = document.getElementById("timeOutput");
            timeOutput.innerHTML = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`; // Format MM:SS

            if (remainingTime <= 0) {
                clearInterval(timerInterval); // Stop the timer
                isTimerActive = false; // Reset the flag
                input.blur()
                

                calculateAccuracy()
            }

            remainingTime -= 1;
        }, 1000); // Runs every second
    }

    // Start the countdown with the selected duration
    startCountdown(parseInt(timerAmt));
});



function countTypedWords(inputText) {
  return inputText.trim().split(/\s+/).length;
}
























  document.getElementById("timeButton").addEventListener('click', function(){
    const timerAmt = document.getElementById('mode').value;
    const accOutput = document.getElementById("accuracy");
    const wpmOutput = document.getElementById("wpm");  // Assuming you have an element with id 'wpm' to display WPM
  
    let startTime = Date.now(); // Record the start time of the timer
  
    function startCountdown(durationInSeconds) {
      input.setSelectionRange(0, 0);
      let remainingTime = durationInSeconds;
  
      const timerInterval = setInterval(() => {
          const minutes = Math.floor(remainingTime / 60);
          const seconds = remainingTime % 60;
  
          let timeOutput = document.getElementById("timeOutput");
          timeOutput.innerHTML = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`; // Format MM:SS
  
          if (remainingTime <= 0) {
              clearInterval(timerInterval); // Stop the timer
  
              // Get the text typed by the user
              let typedText = input.value.trim();
              const wordCount = countTypedWords(typedText);
  




              let spacesTyped = 0
              input.addEventListener('keydown', (e) => {
                if (e.key === ' ') {
                  spacesTyped++; // Increment spaces counter on space key press
                }
              });







              // Calculate WPM (words typed / time in minutes)
              
              
              const elapsedMinutes = (timerAmt/60)
              
              
              const wpm = ((correct+incorrect)/5) / elapsedMinutes;
  
              // Display WPM and accuracy
              wpmOutput.innerHTML = wpm.toFixed(0);  // Display WPM (rounded to 2 decimal places)
  
                          
  
              alert("Countdown complete!");  // Show alert when the time is up
          }
  
          remainingTime -= 1;
      }, 1000); // Runs every second
    }
  
    // Start countdown based on selected timer value
    startCountdown(parseInt(timerAmt));
  });
  
  // Helper function to count the number of words typed
  function countTypedWords(inputText) {
    return inputText.trim().split(/\s+/).length;
  }
  
  // Function to calculate accuracy percentage
  function calculateAccuracy() {
    let totalChar = incorrect+correct
    console.log("total characters")
    console.log(totalChar)
    console.log("correct chracters")
    console.log(correct)
    console.log("incorrect characters")
    console.log(incorrect)
    
    let accuracy = correct / (incorrect+correct) * 100
    if (isNaN(accOutput)){
          accOutput = 0
        }
    accOutput.innerHTML = accuracy.toFixed(0) + '%';
    
    }

